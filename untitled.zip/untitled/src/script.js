function sendAd() {
  const name = document.getElementById("businessName").value;
  const phone = document.getElementById("phone").value;
  const category = document.getElementById("category").value;
  const description = document.getElementById("description").value;

  const message =
    "طلب إعلان جديد 📢%0A%0A" +
    "اسم النشاط: " + name + "%0A" +
    "رقم الهاتف: " + phone + "%0A" +
    "نوع النشاط: " + category + "%0A" +
    "التفاصيل: " + description;

  const myWhatsApp = "201XXXXXXXXX";

  window.open(
    "https://wa.me/" + myWhatsApp + "?text=" + message,
    "_blank"
  );
}
201124993559